// Simple client-side login (not secure for production)
// Default credentials - change before deploying:
const VALID_USER = "admin";
const VALID_PASS = "demo123";

const loginScreen = document.getElementById('loginScreen');
const playerScreen = document.getElementById('playerScreen');
const btnLogin = document.getElementById('btnLogin');
const btnLogout = document.getElementById('btnLogout');
const statusEl = document.getElementById('status');
const logEl = document.getElementById('log');
const video = document.getElementById('video');

const STREAM_PATH = '/live/liveluis1.m3u8';
const PLAY_URL = location.origin + STREAM_PATH;

function appendLog(msg){
  logEl.textContent = (new Date()).toISOString() + ' - ' + msg + '\n' + logEl.textContent;
  console.log(msg);
}
function setStatus(t){ statusEl.textContent = 'Estado: ' + t; }

function startPlayer(){
  appendLog('Iniciando player con URL: ' + PLAY_URL);
  if (Hls.isSupported()){
    const hls = new Hls({maxBufferLength:30});
    hls.loadSource(PLAY_URL);
    hls.attachMedia(video);
    hls.on(Hls.Events.MANIFEST_PARSED, () => {
      appendLog('Manifest parseado - reproduciendo');
      setStatus('reproduciendo');
      video.play().catch(()=>appendLog('Autoplay bloqueado'));
    });
    hls.on(Hls.Events.ERROR, (evt,data) => {
      appendLog('HLS ERROR: ' + JSON.stringify(data));
      if (data.fatal){
        if (data.type === Hls.ErrorTypes.NETWORK_ERROR){
          appendLog('Error de red - reconectando...');
          setStatus('reconectando...');
          setTimeout(startPlayer, 3000);
        } else if (data.type === Hls.ErrorTypes.MEDIA_ERROR){
          appendLog('Recuperando media...');
          try{ hls.recoverMediaError(); } catch(e){ appendLog('recover failed'); }
        } else {
          appendLog('Error fatal - reiniciando player');
          setTimeout(startPlayer, 2000);
        }
      }
    });
  } else if (video.canPlayType('application/vnd.apple.mpegurl')){
    video.src = PLAY_URL;
    video.addEventListener('loadedmetadata', ()=>video.play().catch(()=>appendLog('Autoplay bloqueado')));
    setStatus('reproduciendo (nativo)');
  } else {
    appendLog('Navegador no soporta HLS');
    setStatus('no soportado');
  }
}

btnLogin.addEventListener('click', ()=>{
  const u = document.getElementById('user').value.trim();
  const p = document.getElementById('pass').value;
  if (u === VALID_USER && p === VALID_PASS){
    loginScreen.style.display = 'none';
    playerScreen.style.display = 'block';
    appendLog('Usuario autorizado: ' + u);
    startPlayer();
  } else {
    appendLog('Credenciales inválidas para usuario: ' + u);
    alert('Credenciales inválidas');
  }
});

btnLogout.addEventListener('click', ()=>{
  location.reload();
});
