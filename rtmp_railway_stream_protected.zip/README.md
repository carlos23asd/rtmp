# rtmp-railway-stream (RTMP + HLS) - Protected Player (client-side)

Clave del stream: `liveluis1`

## Descripción
Proyecto que despliega Nginx con RTMP y salida HLS, y una página web protegida por login (cliente JS). La protección con usuario/clave es **cliente-side** (no segura). Para autenticación real, configura nginx auth_basic o un backend.

## Deploy en Railway (rápido)
1. Crear repo en GitHub con estos archivos o subir este proyecto.
2. En Railway: New Project → Deploy from GitHub → selecciona el repo.
3. Espera build y despliegue.

## Probar ingest (desde tu PC)
Usa FFmpeg (ejemplo copy):
```
ffmpeg -re -i "URL_IPTV_O_ARCHIVO" -c copy -f flv "rtmp://<RAILWAY_HOST>/live/liveluis1"
```
Si Railway no acepta RTMP en puerto 1935, intenta puerto 80:
```
ffmpeg -re -i "URL_IPTV" -c copy -f flv "rtmp://<RAILWAY_HOST>:80/live/liveluis1"
```

## Ver reproductor
- Abre `https://<RAILWAY_HOST>/` → verás login
- Usuario por defecto: `admin`
- Contraseña por defecto: `demo123`
- Cambia las credenciales en `public/player.js` antes de desplegar.

## Notas importantes
- Railway puede poner la app en sleep; HLS usa /tmp/hls en el contenedor y se borra si el container reinicia.
- Para seguridad real usa nginx auth_basic o proxy con autenticación.
